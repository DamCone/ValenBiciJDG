
package com.mycompany.valenbiciapiv2;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;

public class DatosJSon {
 private static String API_URL;
 private String datos = ""; //para mostrar en el jTextArea los datos de las estaciones

 private String [] values; //para añadir los datos de las estaciones Valenbici a la BDD
 private int numEst;

 public DatosJSon(int nE){
 numEst = nE;
 datos = "";
 API_URL = "https://valencia.opendatasoft.com/api/explore/v2.1/catalog/datasets/valenbisi-disponibilitat-valenbisi-dsiponibilidad/records?f=json&location=39.46447,-0.39308&distance=10&limit=" + nE;

 values = new String [numEst];

 for (int i = 0; i < numEst; i++ )
 values[i] = "";
 }


 public void mostrarDatos(int nE){

     numEst = nE;
     datos = ""; // Reinicia 'datos' cada vez que se llama
     API_URL = "https://valencia.opendatasoft.com/api/explore/v2.1/catalog/datasets/valenbisi-disponibilitat-valenbisi-dsiponibilidad/records?f=json&location=39.46447,-0.39308&distance=10&limit=" + nE;

     values = new String [numEst]; // Reinicia 'values' también
     for (int i = 0; i < numEst; i++ )
         values[i] = "";
     

     // No necesitas declarar lon, lat aquí si solo las usas dentro del bucle JSON

     if (API_URL.isEmpty()) {
         setDatos(getDatos().concat("La URL de la API no está especificada."));
         // Ya no necesitamos el return aquí si el código sigue
     }

     // Usamos StringBuilder para construir la cadena 'datos' eficientemente
     StringBuilder datosBuilder = new StringBuilder();

     try (CloseableHttpClient httpClient = HttpClients.createDefault()) { // <-- Abre Try-with-resources (1)
         HttpGet request = new HttpGet(API_URL);
         HttpResponse response = httpClient.execute(request);
         HttpEntity entity = response.getEntity();

         if (entity != null) { // <-- Abre if (2)
             String result = EntityUtils.toString(entity);
             
             

             // Intentamos procesar la respuesta como JSON
             try { // <-- Abre try interno para JSON (3)
                 JSONObject jsonObject = new JSONObject(result);
                 JSONArray resultsArray = jsonObject.getJSONArray("results");

                 // ------------ IMPLEMENTAR EL BUCLE JSON ------------
                 for (int i = 0; i < resultsArray.length(); i++) {
                     JSONObject estacion = resultsArray.getJSONObject(i);

                     // Extraer los datos que necesitas
                     int numero = estacion.getInt("number");
                     String direccion = estacion.getString("address");
                     int disponibles = estacion.getInt("available");
                     int libres = estacion.getInt("free");
                     boolean abierto = estacion.getString("open").equalsIgnoreCase("T"); // Convertir 'T'/'F' a boolean
                     double lon = estacion.getJSONObject("geo_point_2d").getDouble("lon");
                     double lat = estacion.getJSONObject("geo_point_2d").getDouble("lat");
                     String actualizacion = estacion.getString("updated_at"); // Opcional
                     final String DELIMITER = ";"; // Define el delimitador
                    // ... dentro del bucle for ...
                    // ... después de extraer numero, direccion, disponibles, libres, abierto, lon, lat ...

                    // --- Construir la cadena empaquetada y ASIGNARLA a values[i] ---
                    values[i] = numero + DELIMITER +
                                direccion + DELIMITER +
                                disponibles + DELIMITER +
                                libres + DELIMITER +
                                abierto + DELIMITER + // Guardar como "true" o "false"
                                lon + DELIMITER +
                                lat;
                    // ---------------------------------------------------------------

                     // Añadir los datos formateados al StringBuilder
                     datosBuilder.append("Estación: ").append(numero).append(" - ").append(direccion).append("\n");
                     datosBuilder.append("  Disponibles: ").append(disponibles).append("\n");
                     datosBuilder.append("  Libres: ").append(libres).append("\n");
                     datosBuilder.append("  Abierto: ").append(abierto ? "Sí" : "No").append("\n");
                     datosBuilder.append("  Coords: (Lon: ").append(lon).append(", Lat: ").append(lat).append(")\n");
                     datosBuilder.append("------------------------------------\n");

                     // Aquí también podrías guardar los datos en una estructura más útil
                     // que el array `values` si lo necesitaras para la inserción en BD
                     // Por ejemplo, crear una lista de objetos Estacion.
                     // Por ahora, el array 'values' no se está usando de forma útil.

                 }
                  // ------------ FIN DEL BUCLE JSON ------------

             } catch (org.json.JSONException e) { // <-- Mueve el catch de JSON aquí dentro (4)
                 // Si la respuesta no es un array JSON válido o falta algún campo
                  System.err.println("Error al procesar los datos JSON: " + e.getMessage());
                 // Podrías añadir este error a datosBuilder también si quieres mostrarlo en el JTextArea
                 datosBuilder.append("\nError al procesar los datos JSON: ").append(e.getMessage()).append("\n");
                 // Considera añadir: e.printStackTrace(); para más detalles en consola
             } // <-- Cierra catch JSON (4)
         } else {
             datosBuilder.append("No se recibió respuesta de la API (entidad nula).\n");
         } // <-- Cierra if (2)

     } catch (IOException e) { // <-- Mueve el catch de IO aquí (5)
          System.err.println("Error de E/S al contactar la API: " + e.getMessage());
         datosBuilder.append("\nError de E/S al contactar la API: ").append(e.getMessage()).append("\n");
         e.printStackTrace();
     } // <-- Cierra el catch de IO (5) y también el try-with-resources (1) implícitamente


     // Asigna el contenido del StringBuilder a la variable 'datos'
     setDatos(datosBuilder.toString());
 }
 /**
 * @return the datos
 */
 public String getDatos() {
 return datos;
 }
 /**
 * @param datos the datos to set
 */
 public void setDatos(String datos) {
 this.datos = datos;
 }
 /**
 * @return the values
 */
 public String[] getValues() {
 return values;
 }
 /**
 * @param values the values to set
 */
 public void setValues(String[] values) {
 this.values = values;
 }
 /**
 * @return the numEst
 */
 public int getNumEst() {
 return numEst;
 }
 /**
 * @param numEst the numEst to set
 */
 public void setNumEst(int numEst) {
 this.numEst = numEst;
 }
}