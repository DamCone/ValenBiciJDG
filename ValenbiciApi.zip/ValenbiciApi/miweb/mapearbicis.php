<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mapa de Estaciones Valenbisi</title>
</head>
<body>
    <h1>Mapa de Estaciones (En construcción - Tarea 7)</h1>
    <p><a href="index.php">Volver al listado</a></p>
</body>
</html>
